from flask import Flask, render_template, jsonify,json,request,redirect,session
from flask_pymongo import PyMongo
import os
import pymongo

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/hotelCollection'
app.secret_key = os.urandom(24)
mongo = PyMongo(app)
holder = list()
managersTask = [["Customers Relations","Address customer requirements. Review feedback-both positive and negative"],
                  ["Branding & Reputation Management","Reinvent branding strategies to create a brand recall."],
                    ["Provide Mentorship","Help employees develop skill sets , keep high motivational levels and communicate with the team on all matters"],
                    ["Budget Management","Optimize revenue based on demand and manage daily operations"]]

staffTask = [["Housekeeping","Responsible for keeping the hotel clean and safe"],
             ["Room Service", "Take food orders,serve food,process payments and clear tables"],
             ["Kitchen Management","Supervise all food operations, assist chefs in organsing daily menu"],
             ["Event Planning","Co-ordinate special gatherings including arranging guest transportaion and food vendors"]]

receptionistTask = [["Manage Bookings","Assists guests with their check-ins and check-outs"],
                    ["Email Handling","Retrieve mail,packages and documents and address each one accrodingly"],
                    ["Customer Complaints/Queries","Liasie with neccessary staff to address any problem or complaint made by guests."],
                    ["Compue Billings","Prepare billing reports and process accurate payment of guest accounts."]]


@app.route('/')
def viewLogin():
    return render_template("login.html")

@app.route('/dashboard')
def viewDashboard():
    return render_template("dashboard.html")

@app.route('/register', methods=['GET','POST'])
def addEmployee():
    dict={}
    if request.method=='GET':
        return render_template('register.html')    
    if request.method=='POST':
        username=request.form['username']
        for key,val in request.form.items():
            dict[key]=val
        if collection.count_documents({'username':  username}, limit=1) != 0:
            return render_template('register.html')
        else:
            collection.insert_one(dict)
            return redirect('/')

    
@app.route('/', methods=['GET','POST'])
def loginUser():
    if request.method=="POST":
        username=request.form['username']
        password=request.form['password']
        current_user={"username":username,"password":password}
        login_data = collection.find({'username':username},{"username":1,"password":1})
        new_user_data={}
        for i in login_data:
            new_user_data=i
        if new_user_data=={}:
            return "Not records found!!"
        elif current_user["username"]==new_user_data["username"] and current_user["password"]==new_user_data["password"]:
            session["username"]=new_user_data["username"]
            session["password"]=new_user_data["password"]
            return redirect("/dashboard")
        else:
            return "Invalid user"
    else:
        return render_template("login.html")

@app.route('/tasks')
def tasks():
    for i in collection.find():
        if i['job'] == "Manager" and i['username'] == session["username"]:
            reg_details = {"name":i["empname"], "id":i["empid"]}
            taskRecords = managersTask
        elif i['job'] == "Staff" and i['username'] == session["username"]:
            reg_details = {"name":i["empname"], "id":i["empid"]}
            taskRecords = staffTask
        elif i['job'] == "Receptionist" and i['username'] == session["username"]:
            reg_details = {"name":i["empname"], "id":i["empid"]}
            taskRecords = receptionistTask
    empdetails = [["1","Monday",reg_details['id'],reg_details['name']],
                    ["2","Tuesday",reg_details['id'],reg_details['name']],
                      ["3","Wednesday",reg_details['id'],reg_details['name']],
                        ["4","Thursday",reg_details['id'],reg_details['name']]]

    a=0
    for i in empdetails:       
        i.extend(taskRecords[a])
        a+=1
    return render_template('tasks.html',empdetails=empdetails)

if __name__=="__main__":
    print('Welcome to Pymongo')
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['hmsDB']
    collection=db['hotelCollection']
    user_data = {'empid':'','empname':'', 'username':'admin', 'password':'admin123','job':''}
    # collection.insert_one(user_data)
    for i in collection.find():
        holder.append(i)
    app.run(host='0.0.0.0', debug=True, port=8080)